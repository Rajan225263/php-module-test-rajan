<?php
//fetch.php
$connect = mysqli_connect("localhost", "root", "", "php_module_test");
$query = "select c.name, c.Id, cr.ParentcategoryId,
(select count(sub_cr.ParentcategoryId) from catetory_relations sub_cr where sub_cr.ParentcategoryId=cr.ParentcategoryId) AS total_chiled,

(select count(sub_icr.categoryId) from item_category_relations sub_icr inner join item sub_i on sub_icr.ItemNumber=sub_i.Number where sub_icr.categoryId=c.id) as total_item_of_chiled


from category c inner join catetory_relations cr on c.Id=cr.categoryId

group by cr.ParentcategoryId order by cr.ParentcategoryId asc";




$result = mysqli_query($connect, $query);
//$output = array();
while($row = mysqli_fetch_array($result))
{
    $sub_data["id"] = $row["id"];
    $sub_data["name"] = $row["name"];
    $sub_data["text"] = $row["name"];
    $sub_data["parent_id"] = $row["ParentcategoryId"];
    $data[] = $sub_data;
}
foreach($data as $key => &$value)
{
    $output[$value["id"]] = &$value;
}
foreach($data as $key => &$value)
{
    if($value["parent_id"] && isset($output[$value["parent_id"]]))
    {
        $output[$value["parent_id"]]["nodes"][] = &$value;
    }
}
foreach($data as $key => &$value)
{
    if($value["parent_id"] && isset($output[$value["parent_id"]]))
    {
        unset($data[$key]);
    }
}
echo json_encode($data);
/*echo '<pre>';
print_r($data);
echo '</pre>';*/

?>