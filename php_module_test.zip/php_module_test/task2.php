<?php

// Include config file
//require_once "config.php";

/*$sql="select c.name, c.Id, cr.ParentcategoryId,
(select count(sub_cr.ParentcategoryId) from catetory_relations sub_cr where sub_cr.ParentcategoryId=cr.ParentcategoryId) AS total_chiled,

(select count(sub_icr.categoryId) from item_category_relations sub_icr inner join item sub_i on sub_icr.ItemNumber=sub_i.Number where sub_icr.categoryId=c.id) as total_item_of_chiled


from category c inner join catetory_relations cr on c.Id=cr.categoryId

group by cr.ParentcategoryId order by cr.ParentcategoryId asc";*/


?>




<!DOCTYPE html>
<html>
<head>
    <title>Task 2</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-treeview/1.2.0/bootstrap-treeview.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-treeview/1.2.0/bootstrap-treeview.min.css" />

    <style>
    </style>
</head>
<body>
<br /><br />
<div class="container" style="width:900px;">
    <h2 align="center">Task 2</h2>
    <br /><br />
    <div id="treeview"></div>
</div>
</body>
</html>

<script>
    $(document).ready(function(){

        $.ajax({
            url: "fetch.php",
            method:"POST",
            dataType: "json",
            success: function(data)
            {
                $('#treeview').treeview({data: data});
            }
        });

    });
</script>


